import { useRef, useState } from 'react'
import Home from './pages/Home'
import Shop from './pages/Shop'
import Botanica from './pages/Botanica'
import Reservas from './pages/Reservas'
import Foro from './pages/Foro'
import SobreNosotros from './pages/SobreNosotros'
import Patrocinio from './pages/Patrocinio'
import AuthModal from './components/AuthModal'

type Page = 'home' | 'shop' | 'botanica' | 'reservas' | 'foro' | 'nosotros' | 'patrocinio'

const NAV_ITEMS: { id: Page; label: string }[] = [
  { id: 'home', label: 'Inicio' },
  { id: 'shop', label: 'Tienda' },
  { id: 'botanica', label: 'Botánica' },
  { id: 'reservas', label: 'Reservas' },
  { id: 'foro', label: 'Foro' },
  { id: 'nosotros', label: 'Sobre nosotros' },
]

export default function App() {
  const [page, setPage] = useState<Page>('home')
  const [menuOpen, setMenuOpen] = useState(false)
  const [authOpen, setAuthOpen] = useState(false)
  const authTrigger = useRef<HTMLButtonElement>(null)

  function closeAuth() {
    setAuthOpen(false)
    authTrigger.current?.focus()
  }

  function navigate(p: string) {
    setPage(p as Page)
    setMenuOpen(false)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function navigateContact() {
    setPage('nosotros')
    setMenuOpen(false)
    requestAnimationFrame(() => document.getElementById('contacto')?.scrollIntoView({ behavior: 'smooth' }))
  }

  return (
    <div className="bg-[#080c06] min-h-screen">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-40 border-b border-[#1e2e1a] bg-[#080c06ee] backdrop-blur-md">
        <div className="px-4 sm:px-6 md:px-12 xl:px-16 flex items-center justify-between gap-2 h-16">
          {/* Logo */}
          <button
            onClick={() => navigate('home')}
            className="flex shrink-0 items-center gap-2 sm:gap-3 group"
          >
            <div className="w-6 h-6 sm:w-7 sm:h-7 bg-[#c5f135] flex items-center justify-center text-[#080c06] text-sm font-black select-none">
              ✿
            </div>
            <span className="font-display font-black text-[#f0ede6] text-xs sm:text-lg tracking-tight leading-none">
              Deep<span className="text-[#c5f135] italic">in the</span>Flower
            </span>
          </button>

          {/* Desktop nav */}
          <div className="hidden xl:flex items-center gap-0">
            {NAV_ITEMS.map(item => (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`font-mono text-xs tracking-widest uppercase px-3 py-2 transition-all duration-150 ${
                  (page === item.id || (page === 'patrocinio' && item.id === 'nosotros'))
                    ? 'text-[#c5f135]'
                    : 'text-[#8fa882] hover:text-[#f0ede6]'
                }`}
              >
                {item.label}
                {(page === item.id || (page === 'patrocinio' && item.id === 'nosotros')) && (
                  <div className="w-full h-px bg-[#c5f135] mt-0.5" />
                )}
              </button>
            ))}
          </div>

          {/* CTA + hamburger */}
          <div className="flex shrink-0 items-center gap-2 xl:gap-3">
            <button
              onClick={() => navigate('shop')}
              className="hidden xl:block font-mono text-xs tracking-widest uppercase px-4 py-2 bg-[#c5f135] text-[#080c06] hover:bg-[#d4ff40] transition-colors"
            >
              Comprar
            </button>
            {/* Hamburger */}
            <button
              className="xl:hidden flex flex-col gap-1.5 p-2"
              onClick={() => setMenuOpen(o => !o)}
              aria-label="Menú"
              aria-expanded={menuOpen}
            >
              <span className={`block w-5 h-px bg-[#f0ede6] transition-all duration-200 ${menuOpen ? 'rotate-45 translate-y-[7px]' : ''}`} />
              <span className={`block w-5 h-px bg-[#f0ede6] transition-all duration-200 ${menuOpen ? 'opacity-0' : ''}`} />
              <span className={`block w-5 h-px bg-[#f0ede6] transition-all duration-200 ${menuOpen ? '-rotate-45 -translate-y-[7px]' : ''}`} />
            </button>
            <button
              ref={authTrigger}
              type="button"
              onClick={() => { setMenuOpen(false); setAuthOpen(true) }}
              aria-label="Iniciar sesión o crear cuenta"
              className="shrink-0 border border-[#8fa882] px-2 py-2 font-mono text-xs uppercase tracking-wide text-[#f0ede6] transition-colors hover:border-[#c5f135] hover:text-[#c5f135] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary sm:px-4 sm:tracking-widest"
            >
              <span className="sm:hidden">Entrar</span><span className="hidden sm:inline">Iniciar sesión</span>
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="xl:hidden border-t border-[#1e2e1a] bg-[#080c06] px-6 py-4">
            {NAV_ITEMS.map(item => (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`block w-full text-left font-mono text-sm tracking-widest uppercase py-3 border-b border-[#1e2e1a] transition-colors ${
                  (page === item.id || (page === 'patrocinio' && item.id === 'nosotros')) ? 'text-[#c5f135]' : 'text-[#8fa882]'
                }`}
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => navigate('shop')}
              className="mt-4 w-full py-3 bg-[#c5f135] text-[#080c06] font-mono text-xs tracking-widest uppercase"
            >
              Comprar →
            </button>
          </div>
        )}
      </nav>

      {/* Page content */}
      <div className="pt-16">
        {page === 'home' && <Home onNavigate={navigate} />}
        {page === 'shop' && <Shop />}
        {page === 'botanica' && <Botanica />}
        {page === 'reservas' && <Reservas />}
        {page === 'foro' && <Foro />}
        {page === 'nosotros' && <SobreNosotros onNavigate={navigate} />}
        {page === 'patrocinio' && <Patrocinio onNavigate={navigate} />}
      </div>

      {/* Footer */}
      <footer className="border-t border-[#1e2e1a] px-6 md:px-12 lg:px-20 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-8 bg-[#c5f135] flex items-center justify-center text-[#080c06] font-black">✿</div>
              <span className="font-display font-black text-[#f0ede6] text-xl">DeepInTheFlower</span>
            </div>
            <p className="font-body text-[#8fa882] text-sm leading-relaxed max-w-xs">
              Floristería online con entrega en 48h. Plantas, flores, semillas y decoración floral para cada momento.
            </p>
            <p className="font-mono text-[#3a4d36] text-xs mt-6">© 2026 DeepInTheFlower · Barcelona</p>
          </div>

          {[
            { title: 'Tienda', links: ['Flores', 'Plantas', 'Semillas', 'Macetas', 'Herramientas'] },
            { title: 'Nosotros', links: ['Sobre nosotros', 'Patrocinio', 'Botánica', 'Foro', 'Contacto'] },
          ].map(col => (
            <div key={col.title}>
              <p className="font-mono text-[#f0ede6] text-[10px] tracking-widest uppercase mb-4">{col.title}</p>
              <ul className="space-y-2">
                {col.links.map(link => (
                  <li key={link}>
                    {col.title === 'Nosotros' ? (
                      <button
                        onClick={() => link === 'Contacto' ? navigateContact() : navigate(({ 'Sobre nosotros': 'nosotros', Patrocinio: 'patrocinio', Botánica: 'botanica', Foro: 'foro' } as Record<string, Page>)[link])}
                        className="font-body text-[#8fa882] text-sm hover:text-[#c5f135] transition-colors"
                      >
                        {link}
                      </button>
                    ) : (
                      <span className="font-body text-[#8fa882] text-sm hover:text-[#c5f135] cursor-pointer transition-colors">
                        {link}
                      </span>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 pt-6 border-t border-[#1e2e1a] flex flex-wrap gap-3">
          {['Cleber Heber Fabra', 'Sergio Gómez', 'Cristian Salazar'].map(member => (
            <span key={member} className="font-mono text-[10px] tracking-widest uppercase px-3 py-1 border border-[#1e2e1a] text-[#3a4d36]">
              {member}
            </span>
          ))}
        </div>
      </footer>
      {authOpen && <AuthModal onClose={closeAuth} />}
    </div>
  )
}
